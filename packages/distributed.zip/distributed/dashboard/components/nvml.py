##########################################################################
## nvml.py modified to work with Tegra SoC
##
## this is NOT officially supported. It is a custom module that has been
## written by P. Bernardi (pietro.bernardi@studenti.unipd.it) in order
## to show GPU's usage statistics on the Jetson Nano platform.
##
##########################################################################

import math
import time

from bokeh.models import (
    BasicTicker,
    ColumnDataSource,
    HoverTool,
    NumeralTickFormatter,
    OpenURL,
    TapTool,
    DataRange1d,
    Div,
    FactorRange,
)

from bokeh.plotting import figure
from bokeh.layouts import column
from tornado import escape

from dask.utils import format_bytes

from distributed.dashboard.components import DashboardComponent, add_periodic_callback
from distributed.dashboard.components.scheduler import BOKEH_THEME, TICKS_1024, env
from distributed.dashboard.utils import update, without_property_validation
from distributed.utils import log_errors

NVML_ENABLED = True

class GPUCurrentLoad(DashboardComponent):
    """ How many tasks are on each worker """

    def __init__(self, scheduler, width=600, **kwargs):

        with log_errors():
            self.last = 0
            self.scheduler = scheduler
            self.source = ColumnDataSource(
                {
                    "memory": [1, 2],
                    "memory-half": [0.5, 1],
                    "memory_text": ["1B","2B"],
                    "utilization": [1,2],
                    "utilization-half": [0.5, 1],
                    "utilization_text": ["0.00%","0.00%"],
                    "worker": ["a","b"],
                    "gpu-index": [0,0],
                    "frequency": [1,2],
                    "frequency-half": [0.5, 1],
                    "frequency_text": ["0","0"],
                    "y": [1.5,2.5],
                    "escaped_worker": ["a","b"],
                    "time": [0,0],
                    "gpu-names":["a","b"],
                }
            )

            x_range = DataRange1d(follow="end", follow_interval=1, range_padding=0)
            tools = "reset,xpan,xwheel_zoom"

            # gpu div to show the information about the scheduler's board
            self.gpu_div = Div(
                id="bk-gpu-div",
                name="gpu_div",
                text="",
                height=40,
                **kwargs
            )

            gpu_names = []
            workers = list(self.scheduler.workers.values())
            for idx, ws in enumerate(workers):
                try:
                    info = ws.extra["gpu"]
                except KeyError:
                    continue                                
                gpu_names.append(str("idx:"+str(idx)+"_"+self.scheduler.workers[ws.address].name))
            

            # plot of the frequency
            frequency = figure(
                title="GPU Frequency",
                tools=tools,
                id="bk-gpu-frequency-worker-plot",
                width=int(width / 2),
                name="gpu_frequency_histogram",
                x_range=(0,1024),
                y_range=gpu_names,
                **kwargs
            )
            rect = frequency.rect(
                source=self.source,
                x="frequency-half",
                y="gpu-names",
                width="frequency",
                height=0.5,
                color="#76B900",
            )
            rect.nonselection_glyph = None
            frequency.yaxis.axis_label = "GPU idx"
            frequency.axis[0].ticker = BasicTicker(**TICKS_1024)
            frequency.xaxis[0].formatter = NumeralTickFormatter(format="0.00")
            frequency.xaxis.major_label_orientation = -math.pi / 12
            frequency.x_range.start = 0
            self.frequency = frequency


            # plot of the memory                        
            memory = figure(
                title="GPU Memory",
                tools=tools,
                id="bk-gpu-memory-worker-plot",
                width=int(width / 2),
                name="gpu_memory_histogram",
                x_range=(0,2147483648),
                y_range=gpu_names,
                **kwargs
            )

            #memory.y_range = FactorRange(factors=)

            rect = memory.rect(
                source=self.source,
                x="memory-half",
                y="gpu-names",
                width="memory",
                height=0.5,
                color="#76B900",
            )
            rect.nonselection_glyph = None
            memory.yaxis.axis_label = "GPU idx"
            #memory.yaxis[0].formatter = NumeralTickFormatter(format="0")
            memory.axis[0].ticker = BasicTicker(**TICKS_1024)
            memory.xaxis[0].formatter = NumeralTickFormatter(format="0.0 b")
            memory.xaxis.major_label_orientation = -math.pi / 12
            memory.x_range.start = 0
            self.memory = memory


            # plot of gpu utilization
            utilization = figure(
                title="GPU Utilization",
                tools=tools,
                id="bk-gpu-utilization-worker-plot",
                width=int(width / 2),
                name="gpu_utilization_histogram",
                x_range=(0,1),
                y_range=gpu_names,
                **kwargs
            )
            rect = utilization.rect(
                source=self.source,
                x="utilization-half",
                y="gpu-names",
                width="utilization",
                height=0.5,
                color="#76B900",
            )
            rect.nonselection_glyph = None
            utilization.yaxis.axis_label = "GPU idx"
            #utilization.yaxis[0].formatter = NumeralTickFormatter(format="0")
            utilization.axis[0].ticker = BasicTicker(**TICKS_1024)
            utilization.xaxis[0].formatter = NumeralTickFormatter(format="0.00%")
            utilization.xaxis.major_label_orientation = -math.pi / 12
            utilization.x_range.start = 0
            self.utilization = utilization

            # setting up the callbacks
            for fig in [self.frequency, self.memory, self.utilization]:
                fig.xaxis.minor_tick_line_alpha = 0
                fig.yaxis.visible = True
                fig.ygrid.visible = True

                tap = TapTool(
                    callback=OpenURL(url="./info/worker/@escaped_worker.html")
                )
                fig.add_tools(tap)

                #fig.toolbar.logo = None
                #fig.toolbar_location = None
                #fig.yaxis.visible = False

            hover = HoverTool()
            hover.tooltips = "@worker : @frequency_text"
            hover.point_policy = "follow_mouse"
            self.frequency.add_tools(hover)

            hover = HoverTool()
            hover.tooltips = "@worker : @utilization_text %"
            hover.point_policy = "follow_mouse"
            self.utilization.add_tools(hover)

            hover = HoverTool()
            hover.tooltips = "@worker : @memory_text"
            hover.point_policy = "follow_mouse"
            self.memory.add_tools(hover)

            self.frequency_figure = self.frequency
            self.memory_figure = self.memory
            self.utilization_figure = self.utilization

            plots = [self.frequency, self.memory, self.utilization]
            self.root = column(*plots, **kwargs)

            self.update()

    @without_property_validation
    def update(self):
        with log_errors():
            workers = list(self.scheduler.workers.values())

            frequency = []
            frequency_half = []
            utilization = []
            utilization_half = []            
            memory = []
            memory_half = []
            gpu_index = []
            y = []
            memory_total = 0
            memory_max = 0
            worker = []
            tv = []
            info = None
            gpu_names = []
            
            for idx, ws in enumerate(workers):
                try:
                    info = ws.extra["gpu"]
                except KeyError:
                    continue
                
                metrics = ws.metrics["gpu"]

                t = metrics["time"]
                fr = metrics["frequency"]
                u = metrics["utilization"]/100.
                mem_used = metrics["memory-used"]*10**3
                mem_total = info["memory-total"]*10**3
                memory_max = max(memory_max, mem_total)
                memory_total += mem_total

                frequency.append(int(fr/1000))
                frequency_half.append(int(fr/1000)/2)
                utilization.append(u)
                utilization_half.append(u/2)
                memory.append(mem_used)
                memory_half.append(mem_used/2)
                worker.append(ws.address)
                gpu_index.append(idx)
                gpu_names.append(str("idx:"+str(idx)+"_"+self.scheduler.workers[ws.address].name))
                y.append(idx+0.5)
                tv.append(t)
            

            memory_text = [format_bytes(m) for m in memory]
            frequency_text = [str(f)+" MHz" for f in frequency]
            utilization_text = [str(u*100) for u in utilization]

            result = {
                "frequency": frequency,
                "frequency-half": frequency_half,
                "memory": memory,
                "memory-half": memory_half,
                "memory_text": memory_text,
                "frequency_text": frequency_text,
                "utilization": utilization,
                "utilization-half": utilization_half,
                "utilization_text": utilization_text,
                "worker": worker,
                "gpu-index": gpu_index,
                "gpu-names": gpu_names,
                "y": y,
                "escaped_worker": [escape.url_escape(w) for w in worker],
                "time": tv,
            }

            self.memory_figure.title.text = "Cluster GPU Memory: %s / %s" % (
                format_bytes(sum(memory)),
                format_bytes(memory_total),
            )
            
            if len(frequency_text)>0:
                self.frequency_figure.title.text = "Cluster GPU Frequency: %s / %s" %(
                    round(sum(frequency)/len(frequency),2),
                    "921 MHz"
                )
                self.utilization_figure.title.text = "Cluster GPU Utilization: %s" %(
                    str(round(sum(utilization)/len(utilization)*100,2))+" %"
                )
            if (info is not None):
                self.gpu_div.text = """
                    <b>Board: </b>"""+info["name"]+""" - """+info["board-id"]+""" | 
                    <b>SoC: </b>"""+info["soc-name"]+""" (codename: """+info["soc-codename"]+""") | 
                    <b>Compute Capability: </b>"""+info["compute-capability"]+""" | 
                    <b>System: </b> L4T """+info["l4t-version"]+""" JetPack """+info["jetpack-version"]+"""
                """
            update(self.source, result)

            #self.source.stream(result, 1000)

def gpu_frequency_doc(scheduler, extra, doc):
    with log_errors():
        gpu_load = GPUCurrentLoad(scheduler, sizing_mode="stretch_both")
        gpu_load.update()
        add_periodic_callback(doc, gpu_load, 100)
        doc.add_root(gpu_load.frequency_figure)
        doc.theme = BOKEH_THEME

def gpu_memory_doc(scheduler, extra, doc):
    with log_errors():
        gpu_load = GPUCurrentLoad(scheduler, sizing_mode="stretch_both")
        gpu_load.update()
        add_periodic_callback(doc, gpu_load, 100)
        doc.add_root(gpu_load.memory_figure)
        doc.theme = BOKEH_THEME


def gpu_utilization_doc(scheduler, extra, doc):
    with log_errors():
        gpu_load = GPUCurrentLoad(scheduler, sizing_mode="stretch_both")
        gpu_load.update()
        add_periodic_callback(doc, gpu_load, 100)
        doc.add_root(gpu_load.utilization_figure)
        doc.theme = BOKEH_THEME


def gpu_doc(scheduler, extra, doc):
    with log_errors():
        gpu_load = GPUCurrentLoad(scheduler, sizing_mode="stretch_both")
        gpu_load.update()
        add_periodic_callback(doc, gpu_load, 100)
        doc.add_root(gpu_load.memory_figure)
        doc.add_root(gpu_load.utilization_figure)
        doc.add_root(gpu_load.frequency_figure)
        doc.add_root(gpu_load.gpu_div)

        doc.title = "Dask: GPU"
        doc.theme = BOKEH_THEME
        doc.template = env.get_template("gpu.html")
        doc.template_variables.update(extra)
