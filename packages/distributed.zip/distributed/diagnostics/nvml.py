##########################################################################
## nvml.py modified to work with Tegra SoC
##
## this is NOT officially supported. It is a custom module that has been
## written by P. Bernardi (pietro.bernardi@studenti.unipd.it) in order
## to access the GPU on Nvidia Jetson Nano devices.
##
## this would not have been possible without the great work of R. Bonghi
## who created 'jetson-stats' (https://github.com/rbonghi/jetson_stats)
##
##########################################################################

import os, time
from jtop.core.gpu import GPUService
from jtop.core.memory import meminfo
from jtop.core.hardware import get_hardware

t_init = time.time()

def _jtop_handles():
    gs = GPUService().get_status()['gpu']
    mi = meminfo()
    hw = get_hardware(suppress=True)
    return {'gpu':gs,'mem':mi,'hw':hw}


def real_time():
    h = _jtop_handles()
    return {
        "utilization": h['gpu']['status']['load'], #pynvml.nvmlDeviceGetUtilizationRates(h).gpu,
        "memory-used": h['mem']['NvMapMemUsed'], #pynvml.nvmlDeviceGetMemoryInfo(h).used,
        "frequency": h['gpu']['freq']['cur'],
        "time": time.time()-t_init,
    }


def one_time():
    h = _jtop_handles()
    return {
        "memory-total": h['mem']['MemTotal'], #pynvml.nvmlDeviceGetMemoryInfo(h).total,
        "name": h['hw']['Model'], #pynvml.nvmlDeviceGetName(h).decode(),
        "board-id": h['hw']['BoardIDs'],
        "soc-name": h['hw']['SoC'],
        "compute-capability": h['hw']['CUDA Arch BIN'],
        "soc-codename": h['hw']['Codename'],
        "l4t-version": h['hw']['L4T'],
        "jetpack-version": h['hw']['Jetpack'],
        "time": time.time()-t_init,
    }
