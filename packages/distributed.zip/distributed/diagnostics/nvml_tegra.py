import os
from jtop.core.gpu import GPUService
from jtop.core.memory import meminfo
from jtop.core.hardware import get_hardware

def _jtop_handles():
    gs = GPUService().get_status()
    mi = meminfo()
    hw = get_hardware()
    return {'gpu':gs,'mem':mi,'hw':hw}


def real_time():
    h = _jtop_handles()
    return {
        "utilization": h['gpu']['status']['load'], #pynvml.nvmlDeviceGetUtilizationRates(h).gpu,
        "memory-used": h['mem']['NvMapMemUsed'], #pynvml.nvmlDeviceGetMemoryInfo(h).used,
        "frequency": h['gpu']['freq']['cur'],
    }



def one_time():
    h = _pynvml_handles()
    mname = h['hw']['Model'] + " - " + h['hw']['SoC']
    return {
        "memory-total": h['mem']['MemTotal'], #pynvml.nvmlDeviceGetMemoryInfo(h).total,
        "name": mname, #pynvml.nvmlDeviceGetName(h).decode(),
    }
